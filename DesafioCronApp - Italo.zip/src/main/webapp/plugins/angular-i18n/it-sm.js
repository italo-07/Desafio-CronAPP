require('./angular-locale_it-sm');
module.exports = 'ngLocale';
