require('./angular-locale_sq-xk');
module.exports = 'ngLocale';
