require('./angular-locale_pt-gw');
module.exports = 'ngLocale';
