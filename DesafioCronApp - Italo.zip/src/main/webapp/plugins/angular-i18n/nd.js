require('./angular-locale_nd');
module.exports = 'ngLocale';
