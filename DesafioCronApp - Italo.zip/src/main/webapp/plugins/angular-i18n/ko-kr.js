require('./angular-locale_ko-kr');
module.exports = 'ngLocale';
