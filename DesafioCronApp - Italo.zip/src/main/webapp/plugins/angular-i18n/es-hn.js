require('./angular-locale_es-hn');
module.exports = 'ngLocale';
