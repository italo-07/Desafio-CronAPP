require('./angular-locale_mr-in');
module.exports = 'ngLocale';
