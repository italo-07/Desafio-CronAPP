require('./angular-locale_kl');
module.exports = 'ngLocale';
