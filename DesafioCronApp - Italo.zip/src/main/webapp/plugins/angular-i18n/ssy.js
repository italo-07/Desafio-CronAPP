require('./angular-locale_ssy');
module.exports = 'ngLocale';
