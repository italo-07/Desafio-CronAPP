require('./angular-locale_ky-cyrl');
module.exports = 'ngLocale';
