require('./angular-locale_jmc-tz');
module.exports = 'ngLocale';
