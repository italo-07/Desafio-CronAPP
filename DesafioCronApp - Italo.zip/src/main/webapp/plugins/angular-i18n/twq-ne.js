require('./angular-locale_twq-ne');
module.exports = 'ngLocale';
