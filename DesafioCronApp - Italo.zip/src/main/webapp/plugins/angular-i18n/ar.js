require('./angular-locale_ar');
module.exports = 'ngLocale';
