require('./angular-locale_ti-er');
module.exports = 'ngLocale';
