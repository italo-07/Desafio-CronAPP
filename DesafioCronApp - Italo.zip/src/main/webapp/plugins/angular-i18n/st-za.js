require('./angular-locale_st-za');
module.exports = 'ngLocale';
