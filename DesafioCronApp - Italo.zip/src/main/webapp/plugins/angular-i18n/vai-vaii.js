require('./angular-locale_vai-vaii');
module.exports = 'ngLocale';
