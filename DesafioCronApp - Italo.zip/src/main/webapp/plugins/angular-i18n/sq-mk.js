require('./angular-locale_sq-mk');
module.exports = 'ngLocale';
