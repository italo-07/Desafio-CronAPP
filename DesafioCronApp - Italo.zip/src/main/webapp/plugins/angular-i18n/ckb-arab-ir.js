require('./angular-locale_ckb-arab-ir');
module.exports = 'ngLocale';
