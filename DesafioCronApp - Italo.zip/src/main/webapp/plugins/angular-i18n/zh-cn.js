require('./angular-locale_zh-cn');
module.exports = 'ngLocale';
