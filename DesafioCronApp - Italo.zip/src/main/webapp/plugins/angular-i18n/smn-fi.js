require('./angular-locale_smn-fi');
module.exports = 'ngLocale';
