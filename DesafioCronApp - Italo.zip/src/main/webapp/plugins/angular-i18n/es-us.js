require('./angular-locale_es-us');
module.exports = 'ngLocale';
