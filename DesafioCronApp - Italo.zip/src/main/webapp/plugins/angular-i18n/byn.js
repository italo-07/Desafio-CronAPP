require('./angular-locale_byn');
module.exports = 'ngLocale';
