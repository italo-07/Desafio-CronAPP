require('./angular-locale_fr-bj');
module.exports = 'ngLocale';
