require('./angular-locale_ksb-tz');
module.exports = 'ngLocale';
