require('./angular-locale_mk-mk');
module.exports = 'ngLocale';
