require('./angular-locale_zgh-ma');
module.exports = 'ngLocale';
