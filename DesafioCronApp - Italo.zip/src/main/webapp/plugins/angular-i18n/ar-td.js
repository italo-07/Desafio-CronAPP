require('./angular-locale_ar-td');
module.exports = 'ngLocale';
