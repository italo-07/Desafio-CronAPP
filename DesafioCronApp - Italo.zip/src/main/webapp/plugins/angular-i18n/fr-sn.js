require('./angular-locale_fr-sn');
module.exports = 'ngLocale';
