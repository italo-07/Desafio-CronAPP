require('./angular-locale_saq-ke');
module.exports = 'ngLocale';
