require('./angular-locale_fr');
module.exports = 'ngLocale';
