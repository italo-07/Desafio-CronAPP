require('./angular-locale_sg-cf');
module.exports = 'ngLocale';
