require('./angular-locale_in');
module.exports = 'ngLocale';
