require('./angular-locale_lo');
module.exports = 'ngLocale';
