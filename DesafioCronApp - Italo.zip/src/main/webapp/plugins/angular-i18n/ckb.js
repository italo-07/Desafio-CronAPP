require('./angular-locale_ckb');
module.exports = 'ngLocale';
