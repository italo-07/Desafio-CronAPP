require('./angular-locale_en-ug');
module.exports = 'ngLocale';
