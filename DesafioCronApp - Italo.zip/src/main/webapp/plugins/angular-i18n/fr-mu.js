require('./angular-locale_fr-mu');
module.exports = 'ngLocale';
