require('./angular-locale_de-ch');
module.exports = 'ngLocale';
