require('./angular-locale_dz-bt');
module.exports = 'ngLocale';
