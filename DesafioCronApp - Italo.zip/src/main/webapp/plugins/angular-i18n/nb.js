require('./angular-locale_nb');
module.exports = 'ngLocale';
