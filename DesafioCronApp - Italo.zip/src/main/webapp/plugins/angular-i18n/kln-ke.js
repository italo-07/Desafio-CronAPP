require('./angular-locale_kln-ke');
module.exports = 'ngLocale';
