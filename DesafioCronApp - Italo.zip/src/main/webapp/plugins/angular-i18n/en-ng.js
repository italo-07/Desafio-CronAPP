require('./angular-locale_en-ng');
module.exports = 'ngLocale';
