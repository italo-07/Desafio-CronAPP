require('./angular-locale_en-bm');
module.exports = 'ngLocale';
