require('./angular-locale_ki');
module.exports = 'ngLocale';
