require('./angular-locale_ug-arab');
module.exports = 'ngLocale';
