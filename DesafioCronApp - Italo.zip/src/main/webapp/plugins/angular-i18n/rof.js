require('./angular-locale_rof');
module.exports = 'ngLocale';
