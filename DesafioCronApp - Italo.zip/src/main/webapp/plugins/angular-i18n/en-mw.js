require('./angular-locale_en-mw');
module.exports = 'ngLocale';
