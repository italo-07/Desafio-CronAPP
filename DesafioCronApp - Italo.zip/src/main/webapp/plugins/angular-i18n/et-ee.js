require('./angular-locale_et-ee');
module.exports = 'ngLocale';
