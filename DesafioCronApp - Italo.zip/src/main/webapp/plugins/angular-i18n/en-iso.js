require('./angular-locale_en-iso');
module.exports = 'ngLocale';
