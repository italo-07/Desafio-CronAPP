require('./angular-locale_zh-hans');
module.exports = 'ngLocale';
