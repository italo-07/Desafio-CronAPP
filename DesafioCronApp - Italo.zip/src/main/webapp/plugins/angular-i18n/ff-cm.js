require('./angular-locale_ff-cm');
module.exports = 'ngLocale';
