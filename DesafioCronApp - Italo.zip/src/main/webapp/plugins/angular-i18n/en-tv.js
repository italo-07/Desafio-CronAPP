require('./angular-locale_en-tv');
module.exports = 'ngLocale';
