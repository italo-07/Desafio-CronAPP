require('./angular-locale_kok-in');
module.exports = 'ngLocale';
