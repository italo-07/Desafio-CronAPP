require('./angular-locale_ru-kg');
module.exports = 'ngLocale';
