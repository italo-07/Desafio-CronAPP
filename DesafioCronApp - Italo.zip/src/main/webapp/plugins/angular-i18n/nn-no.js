require('./angular-locale_nn-no');
module.exports = 'ngLocale';
