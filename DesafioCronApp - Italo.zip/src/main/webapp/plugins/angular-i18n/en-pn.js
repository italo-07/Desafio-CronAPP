require('./angular-locale_en-pn');
module.exports = 'ngLocale';
