require('./angular-locale_shi-tfng-ma');
module.exports = 'ngLocale';
