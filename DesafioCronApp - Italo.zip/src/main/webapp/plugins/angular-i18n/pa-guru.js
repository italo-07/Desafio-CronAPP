require('./angular-locale_pa-guru');
module.exports = 'ngLocale';
