require('./angular-locale_sr-latn-ba');
module.exports = 'ngLocale';
