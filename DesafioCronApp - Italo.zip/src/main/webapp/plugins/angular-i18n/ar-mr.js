require('./angular-locale_ar-mr');
module.exports = 'ngLocale';
