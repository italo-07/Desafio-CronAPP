require('./angular-locale_es-pr');
module.exports = 'ngLocale';
