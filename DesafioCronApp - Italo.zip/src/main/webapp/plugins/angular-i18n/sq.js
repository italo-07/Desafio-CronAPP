require('./angular-locale_sq');
module.exports = 'ngLocale';
