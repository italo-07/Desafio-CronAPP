require('./angular-locale_en-nu');
module.exports = 'ngLocale';
