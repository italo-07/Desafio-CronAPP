require('./angular-locale_ve-za');
module.exports = 'ngLocale';
