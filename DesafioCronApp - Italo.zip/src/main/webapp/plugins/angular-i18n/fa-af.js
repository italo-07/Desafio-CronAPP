require('./angular-locale_fa-af');
module.exports = 'ngLocale';
