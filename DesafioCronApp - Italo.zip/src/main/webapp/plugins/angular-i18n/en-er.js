require('./angular-locale_en-er');
module.exports = 'ngLocale';
