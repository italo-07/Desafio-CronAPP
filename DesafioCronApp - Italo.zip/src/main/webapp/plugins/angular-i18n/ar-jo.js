require('./angular-locale_ar-jo');
module.exports = 'ngLocale';
