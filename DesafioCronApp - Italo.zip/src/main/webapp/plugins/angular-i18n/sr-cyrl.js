require('./angular-locale_sr-cyrl');
module.exports = 'ngLocale';
