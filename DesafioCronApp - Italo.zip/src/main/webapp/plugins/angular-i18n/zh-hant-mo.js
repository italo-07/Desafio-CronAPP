require('./angular-locale_zh-hant-mo');
module.exports = 'ngLocale';
