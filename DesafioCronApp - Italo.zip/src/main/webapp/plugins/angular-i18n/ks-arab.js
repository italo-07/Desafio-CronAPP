require('./angular-locale_ks-arab');
module.exports = 'ngLocale';
