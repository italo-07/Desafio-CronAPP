require('./angular-locale_ur');
module.exports = 'ngLocale';
