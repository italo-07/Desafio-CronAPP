require('./angular-locale_fr-be');
module.exports = 'ngLocale';
