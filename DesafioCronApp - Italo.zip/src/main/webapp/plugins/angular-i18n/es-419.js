require('./angular-locale_es-419');
module.exports = 'ngLocale';
