require('./angular-locale_vi');
module.exports = 'ngLocale';
