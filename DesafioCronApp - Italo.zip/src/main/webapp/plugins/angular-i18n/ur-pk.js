require('./angular-locale_ur-pk');
module.exports = 'ngLocale';
