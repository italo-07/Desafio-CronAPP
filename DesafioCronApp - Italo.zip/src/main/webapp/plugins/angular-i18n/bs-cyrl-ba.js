require('./angular-locale_bs-cyrl-ba');
module.exports = 'ngLocale';
