require('./angular-locale_fr-gp');
module.exports = 'ngLocale';
