require('./angular-locale_ar-km');
module.exports = 'ngLocale';
