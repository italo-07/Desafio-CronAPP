require('./angular-locale_en-be');
module.exports = 'ngLocale';
