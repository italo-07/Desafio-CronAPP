require('./angular-locale_fil-ph');
module.exports = 'ngLocale';
