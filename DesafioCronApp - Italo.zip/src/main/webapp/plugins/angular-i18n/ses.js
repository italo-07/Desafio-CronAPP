require('./angular-locale_ses');
module.exports = 'ngLocale';
