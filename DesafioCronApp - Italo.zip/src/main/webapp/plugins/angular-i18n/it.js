require('./angular-locale_it');
module.exports = 'ngLocale';
