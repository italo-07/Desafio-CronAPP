require('./angular-locale_en-sb');
module.exports = 'ngLocale';
