require('./angular-locale_ss');
module.exports = 'ngLocale';
