require('./angular-locale_es-bo');
module.exports = 'ngLocale';
