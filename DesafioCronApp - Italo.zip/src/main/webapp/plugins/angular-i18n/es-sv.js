require('./angular-locale_es-sv');
module.exports = 'ngLocale';
