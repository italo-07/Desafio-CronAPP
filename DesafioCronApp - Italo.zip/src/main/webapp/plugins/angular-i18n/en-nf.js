require('./angular-locale_en-nf');
module.exports = 'ngLocale';
