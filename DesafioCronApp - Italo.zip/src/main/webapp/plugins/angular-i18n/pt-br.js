require('./angular-locale_pt-br');
module.exports = 'ngLocale';
