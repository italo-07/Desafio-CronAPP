require('./angular-locale_as');
module.exports = 'ngLocale';
