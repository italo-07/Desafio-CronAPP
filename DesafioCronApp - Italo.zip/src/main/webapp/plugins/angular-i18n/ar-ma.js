require('./angular-locale_ar-ma');
module.exports = 'ngLocale';
