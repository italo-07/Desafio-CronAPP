require('./angular-locale_mgh');
module.exports = 'ngLocale';
