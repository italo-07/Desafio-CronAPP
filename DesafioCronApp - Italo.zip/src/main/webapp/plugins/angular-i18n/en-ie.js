require('./angular-locale_en-ie');
module.exports = 'ngLocale';
