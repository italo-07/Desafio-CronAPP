require('./angular-locale_bs');
module.exports = 'ngLocale';
