require('./angular-locale_bn-in');
module.exports = 'ngLocale';
