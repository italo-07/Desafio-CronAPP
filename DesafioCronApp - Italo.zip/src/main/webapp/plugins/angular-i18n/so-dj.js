require('./angular-locale_so-dj');
module.exports = 'ngLocale';
