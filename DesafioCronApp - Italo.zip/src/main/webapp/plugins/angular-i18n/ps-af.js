require('./angular-locale_ps-af');
module.exports = 'ngLocale';
