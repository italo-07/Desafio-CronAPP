require('./angular-locale_to-to');
module.exports = 'ngLocale';
