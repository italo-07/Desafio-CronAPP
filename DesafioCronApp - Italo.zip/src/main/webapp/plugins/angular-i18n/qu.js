require('./angular-locale_qu');
module.exports = 'ngLocale';
