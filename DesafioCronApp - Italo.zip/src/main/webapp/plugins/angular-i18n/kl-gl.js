require('./angular-locale_kl-gl');
module.exports = 'ngLocale';
