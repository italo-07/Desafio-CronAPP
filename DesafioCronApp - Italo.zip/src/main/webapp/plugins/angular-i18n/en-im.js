require('./angular-locale_en-im');
module.exports = 'ngLocale';
