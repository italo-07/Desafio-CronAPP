require('./angular-locale_km');
module.exports = 'ngLocale';
