require('./angular-locale_th-th');
module.exports = 'ngLocale';
