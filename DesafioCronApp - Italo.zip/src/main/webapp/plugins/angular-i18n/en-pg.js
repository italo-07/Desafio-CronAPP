require('./angular-locale_en-pg');
module.exports = 'ngLocale';
