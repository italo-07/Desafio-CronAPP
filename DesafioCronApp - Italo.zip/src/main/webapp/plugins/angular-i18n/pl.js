require('./angular-locale_pl');
module.exports = 'ngLocale';
