require('./angular-locale_en-dg');
module.exports = 'ngLocale';
