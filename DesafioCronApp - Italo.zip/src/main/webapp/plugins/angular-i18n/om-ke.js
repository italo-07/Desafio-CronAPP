require('./angular-locale_om-ke');
module.exports = 'ngLocale';
