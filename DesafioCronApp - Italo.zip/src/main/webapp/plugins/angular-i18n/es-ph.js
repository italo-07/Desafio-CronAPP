require('./angular-locale_es-ph');
module.exports = 'ngLocale';
