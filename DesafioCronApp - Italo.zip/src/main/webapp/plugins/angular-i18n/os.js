require('./angular-locale_os');
module.exports = 'ngLocale';
