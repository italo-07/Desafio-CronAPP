require('./angular-locale_en-gg');
module.exports = 'ngLocale';
