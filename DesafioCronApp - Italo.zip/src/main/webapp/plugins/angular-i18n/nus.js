require('./angular-locale_nus');
module.exports = 'ngLocale';
