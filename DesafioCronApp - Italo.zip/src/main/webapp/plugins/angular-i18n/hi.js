require('./angular-locale_hi');
module.exports = 'ngLocale';
