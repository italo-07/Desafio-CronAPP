require('./angular-locale_or');
module.exports = 'ngLocale';
