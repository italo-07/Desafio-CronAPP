require('./angular-locale_mgo-cm');
module.exports = 'ngLocale';
