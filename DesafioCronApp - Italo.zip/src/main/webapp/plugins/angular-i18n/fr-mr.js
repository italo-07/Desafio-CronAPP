require('./angular-locale_fr-mr');
module.exports = 'ngLocale';
