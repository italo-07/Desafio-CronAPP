require('./angular-locale_sah');
module.exports = 'ngLocale';
