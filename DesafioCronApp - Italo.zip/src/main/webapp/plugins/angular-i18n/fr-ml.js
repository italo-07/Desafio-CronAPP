require('./angular-locale_fr-ml');
module.exports = 'ngLocale';
