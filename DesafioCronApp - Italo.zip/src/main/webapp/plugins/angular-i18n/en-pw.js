require('./angular-locale_en-pw');
module.exports = 'ngLocale';
