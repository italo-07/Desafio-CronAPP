require('./angular-locale_fa');
module.exports = 'ngLocale';
