require('./angular-locale_en-mt');
module.exports = 'ngLocale';
