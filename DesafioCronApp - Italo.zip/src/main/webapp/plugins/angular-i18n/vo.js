require('./angular-locale_vo');
module.exports = 'ngLocale';
