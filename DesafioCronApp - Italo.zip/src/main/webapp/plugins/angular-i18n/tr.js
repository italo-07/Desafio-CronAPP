require('./angular-locale_tr');
module.exports = 'ngLocale';
