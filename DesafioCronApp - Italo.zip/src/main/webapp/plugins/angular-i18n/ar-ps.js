require('./angular-locale_ar-ps');
module.exports = 'ngLocale';
