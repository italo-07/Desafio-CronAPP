require('./angular-locale_tzm');
module.exports = 'ngLocale';
