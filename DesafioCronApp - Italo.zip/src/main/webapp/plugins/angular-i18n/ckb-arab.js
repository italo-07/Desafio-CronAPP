require('./angular-locale_ckb-arab');
module.exports = 'ngLocale';
