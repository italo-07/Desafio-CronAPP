require('./angular-locale_en-to');
module.exports = 'ngLocale';
