require('./angular-locale_mn-cyrl-mn');
module.exports = 'ngLocale';
