require('./angular-locale_eu-es');
module.exports = 'ngLocale';
