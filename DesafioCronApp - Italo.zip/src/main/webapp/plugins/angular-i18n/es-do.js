require('./angular-locale_es-do');
module.exports = 'ngLocale';
