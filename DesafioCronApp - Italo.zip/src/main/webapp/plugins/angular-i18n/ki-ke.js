require('./angular-locale_ki-ke');
module.exports = 'ngLocale';
