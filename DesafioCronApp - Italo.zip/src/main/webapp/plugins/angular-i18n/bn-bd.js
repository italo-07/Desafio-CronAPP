require('./angular-locale_bn-bd');
module.exports = 'ngLocale';
