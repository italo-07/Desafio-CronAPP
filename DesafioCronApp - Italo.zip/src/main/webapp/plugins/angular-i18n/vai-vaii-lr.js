require('./angular-locale_vai-vaii-lr');
module.exports = 'ngLocale';
