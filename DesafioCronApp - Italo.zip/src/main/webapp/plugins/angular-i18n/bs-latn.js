require('./angular-locale_bs-latn');
module.exports = 'ngLocale';
