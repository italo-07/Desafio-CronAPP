require('./angular-locale_kde-tz');
module.exports = 'ngLocale';
