require('./angular-locale_rw-rw');
module.exports = 'ngLocale';
