require('./angular-locale_kln');
module.exports = 'ngLocale';
