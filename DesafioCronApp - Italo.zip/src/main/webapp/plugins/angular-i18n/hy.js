require('./angular-locale_hy');
module.exports = 'ngLocale';
