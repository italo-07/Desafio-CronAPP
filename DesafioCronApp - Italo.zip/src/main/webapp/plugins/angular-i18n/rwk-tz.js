require('./angular-locale_rwk-tz');
module.exports = 'ngLocale';
