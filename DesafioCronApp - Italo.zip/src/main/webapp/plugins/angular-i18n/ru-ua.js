require('./angular-locale_ru-ua');
module.exports = 'ngLocale';
