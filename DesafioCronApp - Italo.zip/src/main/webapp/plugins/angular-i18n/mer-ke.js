require('./angular-locale_mer-ke');
module.exports = 'ngLocale';
