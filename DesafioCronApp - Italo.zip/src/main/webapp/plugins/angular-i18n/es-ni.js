require('./angular-locale_es-ni');
module.exports = 'ngLocale';
