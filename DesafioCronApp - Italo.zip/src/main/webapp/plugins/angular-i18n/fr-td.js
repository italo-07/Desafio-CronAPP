require('./angular-locale_fr-td');
module.exports = 'ngLocale';
