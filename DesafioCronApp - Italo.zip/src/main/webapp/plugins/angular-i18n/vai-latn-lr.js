require('./angular-locale_vai-latn-lr');
module.exports = 'ngLocale';
