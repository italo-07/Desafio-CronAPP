require('./angular-locale_cy');
module.exports = 'ngLocale';
