require('./angular-locale_yav');
module.exports = 'ngLocale';
