require('./angular-locale_en-as');
module.exports = 'ngLocale';
