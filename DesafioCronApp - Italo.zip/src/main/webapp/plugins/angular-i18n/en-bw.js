require('./angular-locale_en-bw');
module.exports = 'ngLocale';
