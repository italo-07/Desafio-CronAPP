require('./angular-locale_de-li');
module.exports = 'ngLocale';
