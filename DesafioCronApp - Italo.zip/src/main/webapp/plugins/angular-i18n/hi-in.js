require('./angular-locale_hi-in');
module.exports = 'ngLocale';
