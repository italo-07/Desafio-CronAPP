require('./angular-locale_lag-tz');
module.exports = 'ngLocale';
