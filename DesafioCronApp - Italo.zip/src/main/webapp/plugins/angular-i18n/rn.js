require('./angular-locale_rn');
module.exports = 'ngLocale';
