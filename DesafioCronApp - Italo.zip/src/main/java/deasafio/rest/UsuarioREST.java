package deasafio.rest;

import org.springframework.data.domain.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.validation.annotation.*;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.*;
import org.springframework.beans.factory.annotation.*;
import java.util.*;
import deasafio.entity.*;
import deasafio.business.*;

/**
 * Controller para expor serviços REST de Usuario
 * 
 * @generated
 **/
@RestController
@RequestMapping(value = "/api/rest/deasafio/Usuario")
public class UsuarioREST {

  /**
   * Classe de negócio para manipulação de dados
   * 
   * @generated
   */
  @Autowired
  @Qualifier("UsuarioBusiness")
  private UsuarioBusiness usuarioBusiness;

  /**
   * @generated
   */
  @Autowired
  @Qualifier("CarroBusiness")
  private CarroBusiness carroBusiness;

  /**
   * Serviço exposto para novo registro de acordo com a entidade fornecida
   * 
   * @generated
   */
  @RequestMapping(method = RequestMethod.POST)
  public Usuario post(@Validated @RequestBody final Usuario entity) throws Exception {
    return usuarioBusiness.post(entity);
  }

  /**
   * Serviço exposto para salvar alterações de acordo com a entidade fornecida
   * 
   * @generated
   */
  @RequestMapping(method = RequestMethod.PUT)
  public Usuario put(@Validated @RequestBody final Usuario entity) throws Exception {
    return usuarioBusiness.put(entity);
  }

  /**
   * Serviço exposto para salvar alterações de acordo com a entidade e id fornecidos
   * 
   * @generated
   */
  @RequestMapping(method = RequestMethod.PUT, value = "/{id}")
  public Usuario put(@PathVariable("id") final java.lang.String id, @Validated @RequestBody final Usuario entity) throws Exception {
    return usuarioBusiness.put(entity);
  }

  /**
   * Serviço exposto para remover a entidade de acordo com o id fornecido
   * 
   * @generated
   */
  @RequestMapping(method = RequestMethod.DELETE, value = "/{id}")
  public void delete(@PathVariable("id") java.lang.String id) throws Exception {
    usuarioBusiness.delete(id);
  }


  /**
   * NamedQuery list
   * @generated
   */
  @RequestMapping(method = RequestMethod.GET
  )    
  public  HttpEntity<PagedResources<Usuario>> listParams (Pageable pageable, PagedResourcesAssembler assembler){
    return new ResponseEntity<>(assembler.toResource(usuarioBusiness.list(pageable   )), HttpStatus.OK);    
  }

  /**
   * NamedQuery listById
   * @generated
   */
  @RequestMapping(method = RequestMethod.GET
  , value="/listById/{id}")    
  public  HttpEntity<PagedResources<Usuario>> listByIdParams (@PathVariable("id") java.lang.String id, Pageable pageable, PagedResourcesAssembler assembler){
    return new ResponseEntity<>(assembler.toResource(usuarioBusiness.listById(id, pageable   )), HttpStatus.OK);    
  }



  /**
   * OneToMany Relationship GET
   * @generated
   */
  @RequestMapping(method = RequestMethod.GET
  , value="/{instanceId}/Carro")    
  public HttpEntity<PagedResources<Carro>> findCarro(@PathVariable("instanceId") java.lang.String instanceId, Pageable pageable, PagedResourcesAssembler assembler) {
    return new ResponseEntity<>(assembler.toResource(usuarioBusiness.findCarro(instanceId,  pageable )), HttpStatus.OK);
  }

  /**
   * OneToMany Relationship DELETE 
   * @generated
   */  
  @RequestMapping(method = RequestMethod.DELETE
  , value="/{instanceId}/Carro/{relationId}")    
  public void deleteCarro(@PathVariable("relationId") java.lang.String relationId) throws Exception {
    this.carroBusiness.delete(relationId);
  }
  
  /**
   * OneToMany Relationship PUT
   * @generated
   */  
  @RequestMapping(method = RequestMethod.PUT
  , value="/{instanceId}/Carro/{relationId}")
  public Carro putCarro(@Validated @RequestBody final Carro entity, @PathVariable("relationId") java.lang.String relationId) throws Exception {
    return this.carroBusiness.put(entity);
  }  
  
  /**
   * OneToMany Relationship POST
   * @generated
   */  
  @RequestMapping(method = RequestMethod.POST
  , value="/{instanceId}/Carro")
  public Carro postCarro(@Validated @RequestBody final Carro entity, @PathVariable("instanceId") java.lang.String instanceId) throws Exception {
  Usuario usuario = this.usuarioBusiness.get(instanceId);
  entity.setUsuario(usuario);
    return this.carroBusiness.post(entity);
  }   




  /**
   * Serviço exposto para recuperar a entidade de acordo com o id fornecido
   * 
   * @generated
   */
  @RequestMapping(method = RequestMethod.GET, value = "/{id}")
  public Usuario get(@PathVariable("id") java.lang.String id) throws Exception {
    return usuarioBusiness.get(id);
  }
}