package deasafio.entity;
import java.io.*;
import javax.persistence.*;
import java.util.*;
import javax.xml.bind.annotation.*;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Classe que representa a tabela ABASTECIMENTO
 * @generated
 */
@Entity
@Table(name = "\"ABASTECIMENTO\""
)
@XmlRootElement
public class Abastecimento implements Serializable {

  /**
   * UID da classe, necessário na serialização 
   * @generated
   */
  private static final long serialVersionUID = 36299697l;
  
  /**
   * @generated
   */
  @Id
    
  @Column(name = "id", insertable=true, updatable=true)
  private java.lang.String id = UUID.randomUUID().toString().toUpperCase();
  /**
   * @generated
   */
  @Column(name = "data", nullable = false, unique = false, insertable=true, updatable=true)
  private java.lang.String data;
  /**
   * @generated
   */
  @Column(name = "posto", nullable = false, unique = false, insertable=true, updatable=true)
  private java.lang.String posto;
  /**
   * @generated
   */
  @Column(name = "carro", nullable = false, unique = false, insertable=true, updatable=true)
  private java.lang.String carro;
  /**
   * @generated
   */
  @Column(name = "km_rodado", nullable = false, unique = false, insertable=true, updatable=true)
  private java.lang.Integer km_rodado;
  /**
   * @generated
   */
  @Column(name = "litros", nullable = false, unique = false, insertable=true, updatable=true)
  private java.lang.Integer litros;
  /**
   * @generated
   */
  @Column(name = "combustivel", nullable = false, unique = false, insertable=true, updatable=true)
  private java.lang.String combustivel;
  /**
   * @generated
   */
  @Column(name = "preco", nullable = false, unique = false, insertable=true, updatable=true)
  private java.lang.Double preco;
  /**
   * @generated
   */
  @Column(name = "usuario", nullable = false, unique = false, insertable=true, updatable=true)
  private java.lang.String usuario;
  /**
   * @generated
   */
  @ManyToOne
  @JoinColumn(name="fk_carro_1", referencedColumnName = "id", insertable=true, updatable=true)
  private Carro carro_1;
  /**
   * @generated
   */
  @ManyToOne
  @JoinColumn(name="fk_posto_1", referencedColumnName = "id", insertable=true, updatable=true)
  private Posto posto_1;
  
  /**
   * Construtor
   * @generated
   */
  public Abastecimento(){
  }

  
  /**
   * Obtém id
   * @param id id
   * return id
   * @generated
   */
  public java.lang.String getId(){
    return this.id;
  }
  
  /**
   * Define id
   * @param id id
   * @generated
   */
  public Abastecimento setId(java.lang.String id){
    this.id = id;
    return this;
  }
  
  /**
   * Obtém data
   * @param data data
   * return data
   * @generated
   */
  public java.lang.String getData(){
    return this.data;
  }
  
  /**
   * Define data
   * @param data data
   * @generated
   */
  public Abastecimento setData(java.lang.String data){
    this.data = data;
    return this;
  }
  
  /**
   * Obtém posto
   * @param posto posto
   * return posto
   * @generated
   */
  public java.lang.String getPosto(){
    return this.posto;
  }
  
  /**
   * Define posto
   * @param posto posto
   * @generated
   */
  public Abastecimento setPosto(java.lang.String posto){
    this.posto = posto;
    return this;
  }
  
  /**
   * Obtém carro
   * @param carro carro
   * return carro
   * @generated
   */
  public java.lang.String getCarro(){
    return this.carro;
  }
  
  /**
   * Define carro
   * @param carro carro
   * @generated
   */
  public Abastecimento setCarro(java.lang.String carro){
    this.carro = carro;
    return this;
  }
  
  /**
   * Obtém km_rodado
   * @param km_rodado km_rodado
   * return km_rodado
   * @generated
   */
  public java.lang.Integer getKm_rodado(){
    return this.km_rodado;
  }
  
  /**
   * Define km_rodado
   * @param km_rodado km_rodado
   * @generated
   */
  public Abastecimento setKm_rodado(java.lang.Integer km_rodado){
    this.km_rodado = km_rodado;
    return this;
  }
  
  /**
   * Obtém litros
   * @param litros litros
   * return litros
   * @generated
   */
  public java.lang.Integer getLitros(){
    return this.litros;
  }
  
  /**
   * Define litros
   * @param litros litros
   * @generated
   */
  public Abastecimento setLitros(java.lang.Integer litros){
    this.litros = litros;
    return this;
  }
  
  /**
   * Obtém combustivel
   * @param combustivel combustivel
   * return combustivel
   * @generated
   */
  public java.lang.String getCombustivel(){
    return this.combustivel;
  }
  
  /**
   * Define combustivel
   * @param combustivel combustivel
   * @generated
   */
  public Abastecimento setCombustivel(java.lang.String combustivel){
    this.combustivel = combustivel;
    return this;
  }
  
  /**
   * Obtém preco
   * @param preco preco
   * return preco
   * @generated
   */
  public java.lang.Double getPreco(){
    return this.preco;
  }
  
  /**
   * Define preco
   * @param preco preco
   * @generated
   */
  public Abastecimento setPreco(java.lang.Double preco){
    this.preco = preco;
    return this;
  }
  
  /**
   * Obtém usuario
   * @param usuario usuario
   * return usuario
   * @generated
   */
  public java.lang.String getUsuario(){
    return this.usuario;
  }
  
  /**
   * Define usuario
   * @param usuario usuario
   * @generated
   */
  public Abastecimento setUsuario(java.lang.String usuario){
    this.usuario = usuario;
    return this;
  }
  
  /**
   * Obtém carro_1
   * @param carro_1 carro_1
   * return carro_1
   * @generated
   */
  public Carro getCarro_1(){
    return this.carro_1;
  }
  
  /**
   * Define carro_1
   * @param carro_1 carro_1
   * @generated
   */
  public Abastecimento setCarro_1(Carro carro_1){
    this.carro_1 = carro_1;
    return this;
  }
  
  /**
   * Obtém posto_1
   * @param posto_1 posto_1
   * return posto_1
   * @generated
   */
  public Posto getPosto_1(){
    return this.posto_1;
  }
  
  /**
   * Define posto_1
   * @param posto_1 posto_1
   * @generated
   */
  public Abastecimento setPosto_1(Posto posto_1){
    this.posto_1 = posto_1;
    return this;
  }
  
  /**
   * @generated
   */
  @Override
  public int hashCode() {
        final int prime = 31;
        int result = 1;

        result = prime * result + ((id == null) ? 0 : id.hashCode());

        return result;
    }
  
  /**
   * @generated
   */ 
  @Override
    public boolean equals(Object obj) {
    
      if(this == obj)
        return true;
      
      if(obj == null)
        return false;
      
      if(!(obj instanceof Abastecimento))
        return false;
      
      Abastecimento other = (Abastecimento)obj;
      
    if(this.id == null && other.id != null)
        return false;
      else if(!this.id.equals(other.id))
        return false;
  

      return true;
      
  }
}