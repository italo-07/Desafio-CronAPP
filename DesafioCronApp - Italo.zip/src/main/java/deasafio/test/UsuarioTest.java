package deasafio.test;

/**
 * Classe utilitária de teste Usuario
 * @generated
 **/
public class UsuarioTest {
	
}
