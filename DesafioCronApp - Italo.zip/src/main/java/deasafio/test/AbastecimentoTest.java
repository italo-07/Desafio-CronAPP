package deasafio.test;

/**
 * Classe utilitária de teste Abastecimento
 * @generated
 **/
public class AbastecimentoTest {
	
}
