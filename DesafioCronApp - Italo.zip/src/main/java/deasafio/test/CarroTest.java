package deasafio.test;

/**
 * Classe utilitária de teste Carro
 * @generated
 **/
public class CarroTest {
	
}
