package deasafio.test;

/**
 * Classe utilitária de teste Posto
 * @generated
 **/
public class PostoTest {
	
}
