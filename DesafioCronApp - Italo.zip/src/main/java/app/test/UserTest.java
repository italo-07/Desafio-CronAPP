package app.test;

/**
 * Classe utilitária de teste User
 * @generated
 **/
public class UserTest {
  
}
