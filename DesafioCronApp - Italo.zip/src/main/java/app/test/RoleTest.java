package app.test;

/**
 * Classe utilitária de teste Role
 * @generated
 **/
public class RoleTest {
  
}
