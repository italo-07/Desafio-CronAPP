package app.test;

/**
 * Classe utilitária de teste UserRole
 * @generated
 **/
public class UserRoleTest {
  
}
