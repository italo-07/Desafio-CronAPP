# Criação
Faça uso do assistente: 
Menu de contexto > Novo > Java > JUnit TestClass

OBS: 
Testes unitários em src/test/java
Do contrário, não serão identificados.

# Teste
Para testar, selecione o teste unitário e a seguir:
Menu de contexto > Rodar JUnit Test
